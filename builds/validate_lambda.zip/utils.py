import logging
def set_log(name, log_level=logging.INFO):
    log = logging.getLogger(name)
    if not log.hasHandlers():
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        date_format = "%Y-%m-%d %H:%M:%S"

        handler = logging.StreamHandler()
        formatter = logging.Formatter(log_format,datefmt=date_format)
        handler.setFormatter(formatter)
        log.addHandler(handler)
        log.setLevel(log_level)
    
    log.info("Log Level is set: %s", logging.getLevelName(log_level))
    return log


